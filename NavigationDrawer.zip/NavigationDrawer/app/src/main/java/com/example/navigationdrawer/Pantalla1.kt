package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla1() {
    LazyColumn() {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Hogar",
                    fontSize = 40.sp,
                    modifier = Modifier.padding(top = 10.dp, start = 20.dp)
                )
                Text(
                    text = "Mesa",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.mesa),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Mesa de Comedor Rectangular en Madera (140x80 cm) Royal Design",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {

                Text(
                    text = "Thermomix",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.thermomix),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Un robot de cocina, un electrodoméstico que permite realizar hasta doce funciones de forma independiente o combinada para elaborar recetas de toda clase de forma muy sencilla.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {

                Text(
                    text = "Mecedora",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.mecedora),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Una mecedora, silla mecedora o silla balancín es una silla cuyos pies están unidos a unas láminas inferiores curvadas permitiendo a la persona balancearse adelante y atrás.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }
        }
    }
}