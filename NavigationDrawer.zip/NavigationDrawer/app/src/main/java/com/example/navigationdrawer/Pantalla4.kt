package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla4() {
    LazyColumn() {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Cocina",
                    fontSize = 40.sp,
                    modifier = Modifier.padding(top = 10.dp, start = 20.dp)
                )
                Text(
                    text = "Juego de sartenes",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.sarten),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Conjunto de utensilios de cocina que consta de tres sartenes de acero inoxidable de diferentes tamaños. ",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {

                Text(
                    text = "Set de utensilios de cocina",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.utensilios),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Con este completo set de utensilios de cocina tendrás todas las herramientas que necesitas siempre recogidas, para que las utilices a la hora de elaborar tus recetas.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {

                Text(
                    text = "Set de ollas",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.ollas),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Juego de 3 ollas de induccion Sagan, de acero inoxidable cromado apto para horno.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }
        }
    }
}