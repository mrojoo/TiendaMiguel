package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla3() {
    LazyColumn() {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Ropa",
                    fontSize = 40.sp,
                    modifier = Modifier.padding(top = 10.dp, start = 20.dp)
                )
                Text(
                    text = "Sudadera nike",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.sudadera),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Prenda deportiva de color rojo manga larga y capucha con el logotipo distintivo de Nike.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {

                Text(
                    text = "Parka",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.parka),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Prenda de abrigo larga y resistente diseñada para condiciones climáticas adversas. Fabricada con materiales impermeables y aislantes, como el Gore-Tex o el plumón, cuenta con capucha ajustable, múltiples bolsillos funcionales y detalles de alta calidad.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {

                Text(
                    text = "Blazzers",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.zapatilla),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Modelo icónico de calzado deportivo que combina estilo y comodidad. Con una silueta de perfil alto, suelen presentar una parte superior de cuero, ante u otros materiales duraderos.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }
        }
    }
}