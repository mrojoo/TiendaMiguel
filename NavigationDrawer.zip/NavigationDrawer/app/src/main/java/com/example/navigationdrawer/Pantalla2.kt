package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla2() {
    LazyColumn() {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Electrónica",
                    fontSize = 40.sp,
                    modifier = Modifier.padding(top = 10.dp, start = 20.dp)
                )
                Text(
                    text = "Lenovo Yoga Slim 7 Pro",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.portatil),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "Da un salto revolucionario al rendimiento híbrido del mundo real con el ordenador portátil Lenovo Yoga Slim 7i Pro con procesadores Intel® Evo™, que incluyen Intel Core™ de 12.ª generación, que te ofrece un rendimiento superior cuando más lo necesitas.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {

                Text(
                    text = "Iphone 15",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.iphone),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "El novedoso diseño del iPhone 15 incorpora una parte trasera fabricada con vidrio tintado en masa.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {

                Text(
                    text = "PlayStation 5",
                    fontSize = 25.sp,
                    modifier = Modifier.padding(top=20.dp, start = 20.dp),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Image(
                        painter = painterResource(id = R.drawable.play),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .padding(top = 20.dp)

                    )
                    Text(
                        text = "La PlayStation 5 (PS5) es la consola de videojuegos de última generación de Sony. Ofrece un hardware potente con gráficos avanzados, tiempos de carga rápidos gracias a su SSD, compatibilidad con juegos de PS4 y resolución 4K.",
                        fontSize = 18.sp,
                        modifier = Modifier.padding(),
                    )
                }
            }
        }
    }
}